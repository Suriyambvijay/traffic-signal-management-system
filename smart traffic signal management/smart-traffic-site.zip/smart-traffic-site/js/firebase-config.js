// ============================================================
// FIREBASE CONFIGURATION
// ============================================================
// 1. Go to https://console.firebase.google.com
// 2. Create a project (or use an existing one)
// 3. Project settings > General > "Your apps" > Web app (</>) > register
// 4. Copy the config object Firebase gives you and paste the values below
// 5. Enable Authentication > Sign-in method > Email/Password
// 6. Enable Firestore Database (start in test mode, then lock down rules)
// ============================================================

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Suggested Firestore security rules (paste into Firestore > Rules):
//
// rules_version = '2';
// service cloud.firestore {
//   match /databases/{database}/documents {
//     match /users/{userId} {
//       allow read, write: if request.auth != null && request.auth.uid == userId;
//     }
//     match /users/{userId}/detections/{docId} {
//       allow read, write: if request.auth != null && request.auth.uid == userId;
//     }
//     match /users/{userId}/events/{docId} {
//       allow read, write: if request.auth != null && request.auth.uid == userId;
//     }
//   }
// }
